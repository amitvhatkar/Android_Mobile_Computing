package com.example.swapnil.iamfoodee.Interface;

import android.view.View;

/**
 * Created by swapnil on 4/3/18.
 */

public interface ItemClickListener {

    void onClick(View view, int position, boolean isLongClick);
}
