package com.example.swapnil.iamfoodee.Common;

import com.example.swapnil.iamfoodee.Model.User;

/**
 * Created by swapnil on 4/3/18.
 */

public class Common {

    public static User currentUser;
}
